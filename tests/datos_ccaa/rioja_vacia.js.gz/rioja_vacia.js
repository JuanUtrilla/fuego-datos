

var aCodigos = [

]
var aCadena = [

]
var aColor = [

]
