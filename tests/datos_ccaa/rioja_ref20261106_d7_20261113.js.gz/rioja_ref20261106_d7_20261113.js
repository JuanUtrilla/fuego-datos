
var aCodigos = [

      "OBARENES-TOLOÑO",

      "PDM_OCCIDENTAL",

      "PDM_ORIENTAL",

      "SIERRA",

      "VALLE",

]
var aCadena = [

      "OBARENES-TOLOÑO<br><strong>Fecha: </strong>13/11/2026<br><strong><span style='background-color: rgba(255, 255, 1, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Moderado (19,98)</strong>",

      "PDM_OCCIDENTAL<br><strong>Fecha: </strong>13/11/2026<br><strong><span style='background-color: rgba(147, 208, 78, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Bajo (5,43)</strong>",

      "PDM_ORIENTAL<br><strong>Fecha: </strong>13/11/2026<br><strong><span style='background-color: rgba(1, 176, 241, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Muy bajo (3,73)</strong>",

      "SIERRA<br><strong>Fecha: </strong>13/11/2026<br><strong><span style='background-color: rgba(1, 176, 241, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Muy bajo (1,26)</strong>",

      "VALLE<br><strong>Fecha: </strong>13/11/2026<br><strong><span style='background-color: rgba(255, 255, 1, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Moderado (11,47)</strong>",

]
var aColor = [

      "rgba(255, 255, 1, 0.6)",

      "rgba(147, 208, 78, 0.6)",

      "rgba(1, 176, 241, 0.6)",

      "rgba(1, 176, 241, 0.6)",

      "rgba(255, 255, 1, 0.6)",

]
