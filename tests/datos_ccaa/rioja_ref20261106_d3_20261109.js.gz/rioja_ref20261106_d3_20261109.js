
var aCodigos = [

      "OBARENES-TOLOÑO",

      "PDM_OCCIDENTAL",

      "PDM_ORIENTAL",

      "SIERRA",

      "VALLE",

]
var aCadena = [

      "OBARENES-TOLOÑO<br><strong>Fecha: </strong>9/11/2026<br><strong><span style='background-color: rgba(147, 208, 78, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Bajo (11,07)</strong>",

      "PDM_OCCIDENTAL<br><strong>Fecha: </strong>9/11/2026<br><strong><span style='background-color: rgba(1, 176, 241, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Muy bajo (2,26)</strong>",

      "PDM_ORIENTAL<br><strong>Fecha: </strong>9/11/2026<br><strong><span style='background-color: rgba(1, 176, 241, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Muy bajo (1,06)</strong>",

      "SIERRA<br><strong>Fecha: </strong>9/11/2026<br><strong><span style='background-color: rgba(1, 176, 241, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Muy bajo (2,49)</strong>",

      "VALLE<br><strong>Fecha: </strong>9/11/2026<br><strong><span style='background-color: rgba(1, 176, 241, 0.6);padding: 4px 4px 4px 0;'>Riesgo:</span> Muy bajo (4,71)</strong>",

]
var aColor = [

      "rgba(147, 208, 78, 0.6)",

      "rgba(1, 176, 241, 0.6)",

      "rgba(1, 176, 241, 0.6)",

      "rgba(1, 176, 241, 0.6)",

      "rgba(1, 176, 241, 0.6)",

]
